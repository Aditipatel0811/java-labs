package flight;

public class DomesticFlight implements FlightOperations {
    @Override
    public void checkIn() {
        System.out.println("Checking in for domestic flight");
    }

    @Override
    public void securityCheck() {
        System.out.println("Passing security check for domestic flight");
    }

    @Override
    public void board() {
        System.out.println("Boarding for domestic flight");
    }
}
