package flight;

public class InternationalFlight implements FlightOperations {
    @Override
    public void checkIn() {
        System.out.println("Checking in for international flight");
    }

    @Override
    public void securityCheck() {
        System.out.println("Passing security check for international flight");
    }

    @Override
    public void board() {
        System.out.println("Boarding for international flight");
    }
}
