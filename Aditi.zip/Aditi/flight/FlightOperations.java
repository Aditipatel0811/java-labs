package flight;

public interface FlightOperations {
    void checkIn();

    void securityCheck();

    void board();
}
