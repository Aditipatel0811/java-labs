package aircraft;

public class CargoPlane extends Aircraft {
    double cargoCapacity;

    public void loadCargo() {
        System.out.println("Loading cargo");
    }

    public void unloadCargo() {
        System.out.println("Unloading cargo");
    }
}
