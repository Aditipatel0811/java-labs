package aircraft;

public class PassengerPlane extends Aircraft {
    int passengerCapacity;

    public void emergencyLanding() {
        System.out.println("Performing emergency landing");
        super.land();
    }
}
