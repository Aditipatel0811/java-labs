package aircraft;

public class Aircraft {
    int fuelCapacity;

    public void takeOff() {
        System.out.println("Taking off");
    }

    public void land() {
        System.out.println("Landing");
    }
}
