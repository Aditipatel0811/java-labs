import aircraft.*;
import flight.*;

public class AirlineSystem {
    public static void main(String[] args) {
        PassengerPlane passengerPlane = new PassengerPlane();
        passengerPlane.takeOff();
        passengerPlane.emergencyLanding();

        CargoPlane cargoPlane = new CargoPlane();
        cargoPlane.land();
        cargoPlane.loadCargo();

        DomesticFlight domesticFlight = new DomesticFlight();
        domesticFlight.checkIn();
        domesticFlight.securityCheck();
        domesticFlight.board();

        InternationalFlight internationalFlight = new InternationalFlight();
        internationalFlight.checkIn();
        internationalFlight.securityCheck();
        internationalFlight.board();
    }
}